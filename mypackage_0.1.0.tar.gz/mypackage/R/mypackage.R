#' mypackage
#'
#' Contain generic function for MATH4753 OU
#'
#' @doctype package
#'
#' @author Hoa Hoang
#'
#' @name mypackage
NULL
